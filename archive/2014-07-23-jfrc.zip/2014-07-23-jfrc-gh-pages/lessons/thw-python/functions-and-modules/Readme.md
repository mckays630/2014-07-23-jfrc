Python Functions and Modules
-----------------------

A function is a block of code that performs a specifc task. In this section we
will learn how to utilize available Python functions as well as write our own.

# Sections:

* Python methods for strings

* Writing our own functions

* Importing Python modules

