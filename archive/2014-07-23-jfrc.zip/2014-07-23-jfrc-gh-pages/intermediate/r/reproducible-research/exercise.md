# `knitr` and `make` exercise

