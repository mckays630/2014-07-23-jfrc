
# Data visualization exercises

See `PDF` for exercises 1 and 2.

3. Write a function to take the following inputs:
    - iris species
    - plot type (scatter plot, or barplot)

Then read that species dataset from the csv folder, create the appropriate ggplot and return that object.

If a different species is input, return an error.

**Bonus:** Add plot title as a function argument. Include a default.

