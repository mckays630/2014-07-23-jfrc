
# Functions and control structures

In this section we'll learn how to write functions and deal with various types of control flows.

* Control structures
* Introduction to writing functions
* Basics of writing functions in R
* Scoping rules

