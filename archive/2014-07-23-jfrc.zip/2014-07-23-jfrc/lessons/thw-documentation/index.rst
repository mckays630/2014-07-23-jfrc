Welcome to The Hacker Within!
=================================
This is the University of Chicago Sofware Carperntry Bootcamp 2012


Contents
~~~~~~~~
.. toctree::
    :maxdepth: 1

    close_line

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

