Please document your module here
================================

.. automodule:: close_line
    :members:
