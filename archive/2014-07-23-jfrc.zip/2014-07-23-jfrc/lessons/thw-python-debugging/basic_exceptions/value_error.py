#!/usr/bin/env python
"""
ValueError - Running a function with an improper data type. Usually comes up
when you're trying to convert between strings, floats, and ints
"""

# You can't convert all strings to ints!
print int("Go home, int(). You're drunk.")