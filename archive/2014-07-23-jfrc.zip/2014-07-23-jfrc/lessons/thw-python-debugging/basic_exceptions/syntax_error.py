#!/usr/bin/env python
"""
SyntaxError - There's something wrong with how you wrote the surrounding code.
Check your parentheses, and make sure there are colons where needed.
"""

while True
    print "Where's the colon at?"