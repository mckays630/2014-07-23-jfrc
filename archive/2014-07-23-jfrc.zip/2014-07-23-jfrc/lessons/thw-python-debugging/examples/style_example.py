#!/usr/bin/env python
"""
A myriad of poor formatting, copied from Anthony Scopatz
"""

import os

aNumber = 0.5

def HappyGo_lucky():  
   tten = aNumber * 10 # times ten
   if tten< 60:
         return 60
   else:
     return tten

409

print HappyGo_lucky()
