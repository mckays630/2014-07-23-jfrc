#!/bin/bash
#Here's a sample 454 dataset that can be downloaded without installing SRAtools

wget ftp://ftp.metagenomics.anl.gov/projects/10/4440613.3/processed/299.screen.passed.fna.gz

# If you don't have something like wget and gzip on your system, you should.
