---
layout: lesson
root: ../..
title: Version Control with Git
level: intermediate
---
FIXME: to be written.
