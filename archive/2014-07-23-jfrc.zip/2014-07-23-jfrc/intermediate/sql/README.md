---
layout: lesson
root: ../..
title: Using Databases and SQL
level: intermediate
---
FIXME: to be written.
