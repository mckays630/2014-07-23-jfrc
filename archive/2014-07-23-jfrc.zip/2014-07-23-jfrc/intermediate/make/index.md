---
layout: lesson
root: ../..
title: Automating Tasks with Make
level: intermediate
---
FIXME: introduction

Topics
------
*   [Introduction](00-intro.html)
*   [Basic Tasks](01-basics.html)
*   [Patterns](02-patterns.html)
*   [Rules](03-rules.html)
*   [Macros](04-macros.html)

See Also
--------
*   [Instructor's Guide](guide.html)
*   [Reference](ref.html)

Resources
---------
*   \*.mk: Makefiles used as examples in notes.
