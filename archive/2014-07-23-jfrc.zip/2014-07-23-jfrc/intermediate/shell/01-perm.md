---
layout: lesson
root: ../..
title: Permissions
level: intermediate
---
<div class="objectives" markdown="1">
## Objectives
*   FIXME
</div>

## Lesson

<div class="keypoints" markdown="1">
## Key Points
*   FIXME
</div>

<div class="challenges" markdown="1">
## Challenges

1.  FIXME
</div>
