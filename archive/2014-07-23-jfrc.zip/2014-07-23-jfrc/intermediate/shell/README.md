---
layout: lesson
root: ../..
title: The Unix Shell
level: intermediate
---
FIXME: to be written.
