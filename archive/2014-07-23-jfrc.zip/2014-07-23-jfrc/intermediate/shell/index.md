---
layout: lesson
root: ../..
title: More Unix Shell
level: Intermediate
---
FIXME: intro

Topics
------
1.  [Permissions](01-perm.html)
2.  [Working Remotely](02-ssh.html)
3.  [Variables](03-var.html)
4.  [Job Control](04-job.html)

See Also
--------
*   [Instructor's Guide](guide.html)
*   [Reference](reference.html)

Resources
---------
*   FIXME
