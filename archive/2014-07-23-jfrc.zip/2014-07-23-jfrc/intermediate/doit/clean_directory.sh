#! /bin/sh

rm *.txt
git checkout -- UK_Sunshine_data.txt UK_Tmean_data.txt
git status
