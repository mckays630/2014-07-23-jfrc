
# Functions exercise.

1. Write a function which takes a numeric vector as argument and calculates the mean of the vector.

2. Write a function which takes a single numeric value X as argument and returns a logical value which is TRUE if X is larger than 15, or FALSE otherwise.

3. Extend the previous function by including an extra argument which sets the threshold (i.e. 15 in the previous question).

4. Create a vector with values between 1:100. Take the function from question 1 and use it in an `sapply` (If I haven't covered `sapply` yet, wait till the next section to do this) and elements larger than 72 in the vector.

*Reminder: use the red sticky if you're stuck or need other help*
---