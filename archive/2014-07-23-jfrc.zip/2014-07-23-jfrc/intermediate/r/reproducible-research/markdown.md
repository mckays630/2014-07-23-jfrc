# Markdown

An incredibly simple semantic file format, not too dissimilar from .doc, .rtf or .txt. Markdown makes it easy for even those without a web-publishing background to write prose (including with links, lists, bullets, etc.) and have it displayed like a website. 

* [Markdown cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)
* [Original markdown reference](http://daringfireball.net/projects/markdown/basics)
