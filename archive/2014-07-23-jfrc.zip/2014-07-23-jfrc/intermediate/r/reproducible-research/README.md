# Reproducible research and make

**Installing**

*knitr*  
```coffee
install.packages("knitr", dependencies = TRUE)  
install.packages("pander")
```

For Make and Pandoc installation instructions please see the [additional-software](../additional_software.md) file.