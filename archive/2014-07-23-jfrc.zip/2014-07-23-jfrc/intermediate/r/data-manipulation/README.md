
# Section 03 - Data manipulation in R  

In this section we will work with a couple more example datasets and use it to clean the data, build summaries, and learn the basic of writing functions. 

| Topic | exercise |
| ------ | --------|
| File I/O in R | exercise |
| The apply family of functions | exercise |
| Using plyr and reshape to restructure your data | exercise |



